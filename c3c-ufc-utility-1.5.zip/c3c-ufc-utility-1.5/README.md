# c3c-fbstate
A Chrome extension. Used to import/export fbstate.json file to be used with C3C or any other bots based on fca-unofficial/facebook-chat-api.

See how to install this thing: https://www.youtube.com/embed/KN6UzbisSFo

-----

(Vietnamese-only since the following PSA is for people (mostly in VN) running a forked, malicious package of facebook-chat-api, fca-unofficial, ts-messenger-api):

## PSA: CẢNH BÁO VỀ VIỆC SỬ DỤNG PACKAGE CỦA NGUYỄN THÁI HẢO (HORIZON) VÀ MỘT SỐ PACKAGE MOD KHÁC

GitHub/npm đã đánh dấu package của Horizon (`fca-horizon-remake`) và một số package khác (`fca-disme`, `ts-messenger-api-v2`, ..) có chứa malware (malicious code) vì thế **TUYỆT ĐỐI** không sử dụng các package này nếu không muốn tự tạo nguy cơ bị hack (hoặc bạn tự chịu trách nhiệm về hành vi của mình).

Đây là PSA cảnh báo lần thứ 2 đối với `fca-horizon-remake` do author của package này trước đây đã từng thêm backdoor có thể kích hoạt bằng environment variables.

**HÃY SỬ DỤNG PACKAGE RÕ NGUỒN GỐC VÀ UY TÍN!**
